class EmployeeModel {
  var id;
  var employeeName;
  var employeeSalary;
  var employeeAge;
  var profilImage;

  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
  EmployeeModel({
    this.id,
    this.employeeName,
    this.employeeSalary,
    this.employeeAge,
    this.profilImage,
  });

  // FORMAT TO JSON
  factory EmployeeModel.fromjson(Map<String, dynamic> json) =>   EmployeeModel
    (id: json['id'],
    employeeName: json['employee_name'],
    employeeSalary: json['employee_name'],
    employeeAge: json['employee_name'],
    profilImage: json['employee_name'],
    ); 
}
import 'package:dw_employee_crud/model/employee_model.dart';
import 'package:dw_employee_crud/providers/employee_provider.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../model/employee_model.dart';
import '../providers/employee_provider.dart';

class Employee extends StatelessWidget {
  get data => [
    
    EmployeeModel(id:"1", employeeName: "Didik", employeeSalary:"50000",employeeAge:"50",profilImage:"",),
    EmployeeModel(id:"2", employeeName: "Wanto", employeeSalary:"150000",employeeAge:"49"),
    EmployeeModel(id:"3", employeeName: "Surip", employeeSalary:"250000",employeeAge:"40"),
    EmployeeModel(id:"4", employeeName: "Hajir", employeeSalary:"350000",employeeAge:"60"),
    //EmployeeModel(id:"1", employeeName: "Didik", employeeSalary:"50000",employeeAge:"50"),
    //EmployeeModel(id:"2", employeeName: "Wanto", employeeSalary:"150000",employeeAge:"49"),
    //EmployeeModel(id:"3", employeeName: "Surip", employeeSalary:"250000",employeeAge:"40"),
    //EmployeeModel(id:"4", employeeName: "Hajir", employeeSalary:"350000",employeeAge:"60"),

  ];

  @override
  Widget build(BuildContext context) {
    Provider.of<EmployeeProvider>(context, listen: false).getEmployee();
    return Scaffold(
      appBar: AppBar(
        title: Text('DW Employee CRUD'),
      ),
      body: Container(
        margin: EdgeInsets.all(10),
        child: Consumer<EmployeeProvider>(
          builder: (context, data, _) {
            return ListView.builder(
            itemCount: data.dataEmployee.length,
            itemBuilder: (context, i) {
              return Card(
                elevation: 8,
                child: ListTile(
                  title: Text(
                    data.dataEmployee[i].employeeName,
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  subtitle:Text('Umur: ${data.dataEmployee[i].employeeAge} '), 
                  trailing: Text("\$${data.dataEmployee[i].employeeSalary}"),
                ),
              );
            },
          );
          },
        ),
      ),
    );
  }
}